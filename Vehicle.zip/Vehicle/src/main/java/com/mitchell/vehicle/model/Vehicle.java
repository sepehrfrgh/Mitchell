package com.mitchell.vehicle.model;


/**
 * 
 * 
 * @author Sepehr Foroughi Shafiei
 * 
 * 
 */
public class Vehicle{
	private String Id;
	private int Year;
	private String Make;
	private String Model;
	
	public String getId() {
		return Id;
	}
	public void setId(String id) {
		Id = id;
	}
	public int getYear() {
		return Year;
	}
	public void setYear(int year) {
		Year = year;
	}
	public String getMake() {
		return Make;
	}
	public void setMake(String make) {
		Make = make;
	}
	public String getModel() {
		return Model;
	}
	public void setModel(String model) {
		Model = model;
	}
	
}
