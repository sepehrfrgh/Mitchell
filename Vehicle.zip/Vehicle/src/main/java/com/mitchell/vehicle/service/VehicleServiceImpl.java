package com.mitchell.vehicle.service;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.mitchell.vehicle.model.Vehicle;

/**
 * @author Sepehr Foroughi Shaifie
 * This class is a controller class to implement all the funcationality of CRUD requirments
 * 
 */

public class VehicleServiceImpl implements VehicleService {
	
	private Map<String, Vehicle> cars = new HashMap<String, Vehicle>();
	
	int numVehicles;

	public VehicleServiceImpl(){
		numVehicles = 0;
	}
	
	/**
 	 * Get all the vehicles form our hashmap and add it to vehicle array 	  
 	 * @return array of vehicle objects containing all the vehicle
 	 */	
	public Vehicle[] getAllVehicles() {
		Vehicle[] allCars = cars.values().toArray(new Vehicle[cars.size()]);
		return allCars;
	}
	/**
 	 * Get the vehicle corresponding to the id
 	 * @param id - specific vehicle id that client requested
 	 * @return vehicle object that has corresponding id or return null if it can not find the car
 	 * @throws NullPointerException - if the specified id is null
 	 */	
	public Vehicle getVehicle(String id) {
		Vehicle car = cars.get(id);
		if(car == null) {
			return null;
		}
		return car;
	}
	/**
 	 * Get all the vehicles based on the client input make and add it to array list 
 	 * @param make - input make to get all the vehicle that have same make
 	 * @return vehicle array containing all the vehicle corresponding to input make
 	 */	
	public Vehicle[] getVehicleByMake(String make) {
		ArrayList<Vehicle> chosenMake = new ArrayList<Vehicle>();
		int index = 0;
		for (Map.Entry element : cars.entrySet()) { 
			Vehicle car = (Vehicle) element.getValue();
			if(make.equals(car.getMake())) {
				chosenMake.add(car);
			}
        } 

		return chosenMake.toArray(new Vehicle[chosenMake.size()]);
	}
	
	/**
 	 * Get all the vehicles based on the client input model and add it to array list 
 	 * @param model - input model to get all the vehicle that have same model
 	 * @return vehicle array containing all the vehicle corresponding to input model
 	 */	
	public Vehicle[] getVehicleByModel(String model) {
		ArrayList<Vehicle> chosenModel = new ArrayList<Vehicle>();
		for (Map.Entry element : cars.entrySet()) { 
			Vehicle car = (Vehicle) element.getValue();
			if(model.equals(car.getModel())) {
				chosenModel.add(car);
			}
        } 

		return chosenModel.toArray(new Vehicle[chosenModel.size()]);
	}
	
	/**
 	 * update a car based on user id, year, make and model inputs 
 	 * @param id - selected id for car
 	 * @param year - selected year
 	 * @param make - selected make
 	 * @param model - selected model
 	 * @return true if successfully update a car, false otherwise
 	 */	
	public boolean updateVehicle(String id, int year, String make, String model) {
		if (year < 1950  || year > 2050 ) {
			return false;
		}
		if(make == null || model == null || make.isEmpty() || model.isEmpty() ) {
			return false;
		}
		if(cars.containsKey(id)) {
			Vehicle newCar = cars.get(id);
			newCar.setId(id);
			newCar.setYear(year);
			newCar.setMake(make);
			newCar.setModel(model);
			return true;
		}
		
		return false;
	}
	/**
 	 * create a car based on user id, year, make and model inputs 
 	 * @param id - selected id for car
 	 * @param year - selected year
 	 * @param make - selected make
 	 * @param model - selected model
 	 * @return true if successfully create a car, false otherwise
 	 */	
	public boolean createVehicle(String id, int year, String make, String model) {
		Vehicle newCar = new Vehicle();
		if(cars.containsKey(id)) {
			return false;
		}
		if (year < 1950  || year > 2050 ) {
			return false;
		}
		if(make == null || model == null || make.isEmpty() || model.isEmpty() ) {
			return false;
		}
		newCar.setId(id);
		newCar.setYear(year);
		newCar.setMake(make);
		newCar.setModel(model);
		cars.put(id, newCar);
		numVehicles++;
		return true;
	}
	
	/**
 	 * delete a car that user chose to delete 
 	 * @param id - chosen id of car that user wants to delete
 	 * @return true if successfully delete a car, false otherwise
 	 */	
	public boolean deleteVehicle(String id) {
		if(cars.containsKey(id)) {
			cars.remove(id);
			numVehicles--;
			return true;
		}else {
			return false;
		}
	}
	/**
 	 * helper function  that get the number of vehicle 
 	 * @return number of car 
 	 */	
	public int getSize() {
		return numVehicles;
	}
	/**
 	 * helper function  that print the car 
 	 * @param id - chosen id of car that user wants to print
 	 * @return number of car 
 	 */	
	public void printVehicle(String id) {
		Vehicle item = getVehicle(id);
		if(item != null) {
			System.out.println("Your Vehicle Info: "+ "ID: " +item.getId()+", " + "Year: " +item.getYear()+", " + "Make: " +item.getMake()+", " + "Model: "+ item.getModel());
		}else {
			System.out.println("Sorry your Vehicle is not in our inventory");
		}
		
	}
}
