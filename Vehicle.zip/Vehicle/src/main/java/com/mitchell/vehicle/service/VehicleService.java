package com.mitchell.vehicle.service;

import com.mitchell.vehicle.model.Vehicle;

/**
 * 
 * 
 * @author Sepehr Foroughi Shafiei
 * 
 * 
 */
public interface VehicleService {
	
	public Vehicle[] getAllVehicles();
	
	public Vehicle getVehicle(String id);
	
	public Vehicle[] getVehicleByMake(String make);
	
	public Vehicle[] getVehicleByModel(String model);
	
	public boolean updateVehicle(String id, int year, String make, String model);
	
	public boolean createVehicle(String id, int year, String make, String model);
	
	public boolean deleteVehicle(String id);
	
	public int getSize(); 
	
	public void printVehicle(String id);

}
