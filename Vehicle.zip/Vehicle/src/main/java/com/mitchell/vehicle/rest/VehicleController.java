package com.mitchell.vehicle.rest;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.mitchell.vehicle.model.Vehicle;
import com.mitchell.vehicle.service.VehicleServiceImpl;

/**
 * 
 * @author Sepehr Foroughi Shafiei
 * I created this class to perform all CRUD operation
 * I used postman to test functionality of each methods
 * 
 */

@Path("/data")
public class VehicleController {
	VehicleServiceImpl crud = new VehicleServiceImpl();
	boolean chevy = crud.createVehicle("1", 2018, "chevy", "volt");
	boolean honda = crud.createVehicle("2", 2019, "honda", "civic");
	
	/**
	 * http://localhost:8080/Vehicle/data/getVehicleById/{id}
	 * 
	 */
	@GET
	@Path("/getVehicleById/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	public Vehicle getVehicleById(@PathParam("id") String id) {
		Vehicle car = crud.getVehicle(id);
		return car;
	}
	
	/**
	 * http://localhost:8080/Vehicle/data/getVehicleByMake/{make}
	 * 
	 */
	@GET
	@Path("/getVehicleByMake/{make}")
	@Produces(MediaType.APPLICATION_JSON)
	public Vehicle[] getVehicleByMake(@PathParam("make") String make) {
		Vehicle[] car = crud.getVehicleByMake(make);
		return car;
	}
	
	/**
	 * http://localhost:8080/Vehicle/data/getVehicleByModel/{model}
	 */
	@GET
	@Path("/getVehicleByModel/{model}")
	@Produces(MediaType.APPLICATION_JSON)
	public Vehicle[] getVehicleByModel(@PathParam("model") String model) {
		Vehicle[] car = crud.getVehicleByModel(model);
		return car;
	}
	
	/**
	 * http://localhost:8080/Vehicle/data/getAllVehicle
	 */
	@GET
	@Path("/getAllVehicle")
	@Produces(MediaType.APPLICATION_JSON)
	public Vehicle[] getAllVehicle() {
		Vehicle[] car = crud.getAllVehicles();
		return car;
	}
	
	/**
	 * http://localhost:8080/Vehicle/data/updateVehicle/{id}
	 */
	@PUT
	@Path("/updateVehicle/{id}")
	@Consumes(MediaType.APPLICATION_JSON)
	public String updateVehicle(Vehicle vehicle, @PathParam("id") String id) {
		boolean test = crud.updateVehicle(vehicle.getId(), vehicle.getYear(), vehicle.getModel(), vehicle.getMake());
		String update = "";
		if (test) {
			update = "Vehicle Updated";
		} else
		{
			update = "Vehicle did not get updated";
		}
		return update;
	}
	
	/**
	 * http://localhost:8080/Vehicle/data/createVehicle
	 */
	@POST
	@Path("/createVehicle")
	@Consumes(MediaType.APPLICATION_JSON)
	public String createVehicle(Vehicle vehicle) {
		boolean test = crud.createVehicle(vehicle.getId(), vehicle.getYear(), vehicle.getModel(), vehicle.getMake());
		String create = "";
		if (test) {
			create = "Vehicle Created";
		}else {
			create = "Vehicle didn't Created";
		}
		return create;
	}
	
	/**
	 * http://localhost:8080/Vehicle/data/deleteVehicle/{id}
	 */
	@DELETE
	@Path("/deleteVehicle/{id}")
	@Consumes(MediaType.APPLICATION_JSON)
	public String deleteVehicle(@PathParam("id") String id) {
		boolean test = crud.deleteVehicle(id);
		String create = "";
		if (test) {
			create = "Vehicle Deleted";
		}else {
			create = "Vehicle didn't Deleted";
		}
		return create;
	}
}
