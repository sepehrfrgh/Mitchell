package com.mitchell.vehicle.test;

import org.junit.Test;

import com.mitchell.vehicle.model.Vehicle;
import com.mitchell.vehicle.service.VehicleServiceImpl;

import junit.framework.TestCase;
  
/**
 * 
 * 
 * @author Sepehr Foroughi Shafiei
 * This class uses Junit framework to perfom JUNIT testing
 * I have test for all the methods inside VehicleCrudImpl
 * 
 */
  public class testVehicles extends TestCase {
  
	  private VehicleServiceImpl dealership; 
	  private String chevy = "0"; 
	  private String acura = "1"; 
	  private String ford = "2"; 
	  private String toyota = "3"; 
	  private String honda = "4"; 
	  private String kia = "5";
	  
	  
	  public void setUp() { 
		  dealership = new VehicleServiceImpl();
		  assertTrue(dealership.createVehicle(chevy,2018, "chevy", "volt"));
		  assertTrue(dealership.createVehicle(acura,2019, "acura", "tlx"));
		  assertTrue(dealership.createVehicle(ford,2012, "ford", "mustang"));
		  assertTrue(dealership.createVehicle(toyota,2017, "toyota", "rav4"));
		  assertTrue(dealership.createVehicle(honda,2020, "honda", "civic"));
		  assertTrue(dealership.createVehicle(kia,2015, "kia", "optima")); 
	  }
	  
	  @Test 
	  public void testSize() { 
		  assertEquals("Result:", 6,dealership.getSize()); 
	  }
	  
	  @Test 
	  public void testCreate() { 
		  VehicleServiceImpl cars = new VehicleServiceImpl();
		  boolean carId = cars.createVehicle("0",2019, "ford", "fusion"); 
		  Vehicle car = cars.getVehicle("0"); 
		  assertEquals("Result:", 2019, car.getYear());
		  assertTrue("Result:","ford".equals(car.getMake()));
		  assertTrue("Result:","fusion".equals(car.getModel())); 
		  boolean carTestValidation = cars.createVehicle("0",1922, "ford", "mustang");
		  assertFalse("Result:", carTestValidation); 
		  boolean carTestValidation1 = cars.createVehicle("0",2010, "", "mustang");
		  assertFalse("Result:", carTestValidation1); 
		  boolean carTestValidation2 = cars.createVehicle("0",2010, null, "mustang"); 
		  assertFalse("Result:", carTestValidation2); 
		  boolean carTestValidation3 = cars.createVehicle("0",2010, "ford", null); 
		  assertFalse("Result:", carTestValidation3);
	  
	  }
	  
	  @Test 
	  public void testGetAllVehicles() {
	  
		  Vehicle[] inventory = dealership.getAllVehicles(); 
		  assertEquals("Result:",6, inventory.length); 
		  boolean delete = dealership.deleteVehicle(acura);
		  Vehicle[] inventory1 = dealership.getAllVehicles(); 
		  assertEquals("Result:",5,inventory1.length); assertTrue("Result:",delete); 
	  }
	  
	  @Test 
	  public void testGetVehicle() { 
		  Vehicle test1 = dealership.getVehicle(chevy); 
		  Vehicle test2 = dealership.getVehicle(ford);
		  Vehicle test3 = dealership.getVehicle(toyota); 
		  Vehicle test4 = dealership.getVehicle(honda); 
		  Vehicle test5 = dealership.getVehicle(kia);
		  assertEquals("Result:", "chevy", test1.getMake()); 
		  assertEquals("Result:","ford", test2.getMake()); 
		  assertEquals("Result:", "toyota", test3.getMake());
		  assertEquals("Result:", "honda", test4.getMake()); 
		  assertEquals("Result:","kia", test5.getMake()); 
	  }
	  
	  @Test 
	  public void testGetVehicleByMake() { 
		  VehicleServiceImpl factory = new VehicleServiceImpl();
		  assertTrue(factory.createVehicle("0", 2018, "chevy", "Volt"));
		  assertTrue(factory.createVehicle("1", 2019, "chevy", "Bolt"));
		  assertTrue(factory.createVehicle("2", 2012, "chevy", "camaro"));
		  assertTrue(factory.createVehicle("3", 2017, "chevy", "Corvette"));
		  assertTrue(factory.createVehicle("4", 2016, "chevy", "Suburban"));
		  assertTrue(factory.createVehicle("5", 2015, "chevy", "Cruze"));
		  assertTrue(factory.createVehicle("6", 2018, "ford", "F-150"));
		  assertTrue(factory.createVehicle("7", 2019, "ford", "mustang"));
		  assertTrue(factory.createVehicle("8", 2012, "honda", "civic"));
		  assertTrue(factory.createVehicle("9", 2017, "honda", "accord"));
		  assertTrue(factory.createVehicle("10", 2016, "kia", "sportage"));
		  assertTrue(factory.createVehicle("11", 2015, "kia", "sorento"));
		  
		  Vehicle[] chevy = factory.getVehicleByMake("chevy");
		  for(Vehicle i : chevy) {
			  assertEquals("Result by Make:", "chevy", i.getMake());
		  }
		  
	  }
	  
	  @Test 
	  public void testGetVehicleByModel() { 
		  VehicleServiceImpl factory = new VehicleServiceImpl();
		  assertTrue(factory.createVehicle("0", 2018, "chevy", "Volt"));
		  assertTrue(factory.createVehicle("1", 2019, "chevy", "Volt"));
		  assertTrue(factory.createVehicle("2", 2012, "chevy", "Volt"));
		  assertTrue(factory.createVehicle("3", 2017, "chevy", "Corvette"));
		  assertTrue(factory.createVehicle("4", 2016, "chevy", "Corvette"));
		  assertTrue(factory.createVehicle("5", 2015, "chevy", "Corvette"));
		  assertTrue(factory.createVehicle("6", 2018, "ford", "F-150"));
		  assertTrue(factory.createVehicle("7", 2019, "ford", "mustang"));
		  assertTrue(factory.createVehicle("8", 2012, "honda", "civic"));
		  assertTrue(factory.createVehicle("9", 2017, "honda", "civic"));
		  assertTrue(factory.createVehicle("10", 2016, "kia", "sportage"));
		  assertTrue(factory.createVehicle("11", 2015, "kia", "sorento"));
		  
		  Vehicle[] volt = factory.getVehicleByMake("Volt");
		  for(Vehicle i : volt) {
			  assertEquals("Result by Make:", "Volt", i.getModel());
		  }
		  
	  }
	  @Test 
	  public void testUpdateVehicle() { 
		  boolean del = dealership.deleteVehicle(acura); 
		  boolean update1 = dealership.updateVehicle("6", 2010, "benz", "glc"); 
		  assertFalse("Result:", update1); 
		  Vehicle[] inventory2 = dealership.getAllVehicles(); 
	  }
		  
	  @Test 
	  public void testDeleteVehicle() { 
		  boolean deleteCar = dealership.deleteVehicle("7"); assertFalse("Result:", deleteCar); 
		  boolean deleteCar1 = dealership.deleteVehicle(toyota); 
		  assertTrue("Result:", deleteCar1); 
		  boolean deleteCar2 = dealership.deleteVehicle(honda);
		  assertTrue("Result:", deleteCar2); 
		  assertEquals("Result:", 4, dealership.getSize());
	  
	  }
	  
  }
  
 